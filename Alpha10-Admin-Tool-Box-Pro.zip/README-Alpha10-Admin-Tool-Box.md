# Alpha10 Admin Toolbox Pro

Version 1.0.1 - Admin-Konsole für Windows 10/11 - Favoriten per Rechtsklick. Kostenlose Nutzung auf eigenes Risiko.


## Enthaltene Bereiche

- Dashboard mit erweiterter Systemübersicht, Health Score/Systemampel, BIOS-Datum, Reboot-Pending-Status, Lizenzstatus, Berichtsexport, Kurzbericht, Datenträgerstatus, PnP-Gerätefehlern, Druckern, Systemtools, Reboot-/Shutdown-Timer und Shutdown-Timer-Abbruch
- Wartung mit Cleanup-Potenzial, Temp-Bereinigung, Papierkorb, Windows-Update-Cache, SFC, DISM, Komponentenspeicher, Laufwerksoptimierung, Speicherdiagnose, Check Disk, Energiebericht und Wiederherstellungspunkt
- Netzwerk mit Diagnoseprofil, IP-Übersicht, DNS-Servern, Listening Ports, TCP-Porttest, Routing, ARP, Proxy, Hosts-Datei, Netzlaufwerken, DNS-Cache, Ping, Traceroute, DNS-Wechsel, WLAN-Profilen, SMB-Risikofreigaben, Domain Trust, Domain Secure Channel und Netzwerkreset
- Sicherheit mit Defender, Firewall, UAC, Remote Desktop, BitLocker und lokalen Administratoren
- Dienste mit Anzeige, Neustart und Starttyp-Verwaltung
- Prozesse mit Top-Verbrauchern, Prozess beenden und Autostart-Anzeige
- Benutzer mit lokalen Benutzern, Benutzeranlage, Aktivieren/Deaktivieren und Admin-Gruppe
- Tools & Logs mit Ereignissen, Bugcheck-Ereignissen, GPO-Fehlerprotokoll, installierten Programmen, Update-Historie, Treiberliste, Treiber-Risikoanalyse, geplanten Tasks, Task-Fehleranalyse, SMB-Freigaben, Benutzerprofilen, GPUpdate, GPResult, Zeitsync, Batteriebericht, Zuverlässigkeitsverlauf, Logdatei und Report-Ordner

## Hinweise

Viele reine Anzeigen laufen ohne Adminrechte. Ändernde Funktionen zeigen eine Bestätigung und verlangen Administratorrechte. Logs werden im Ordner `logs`, Systemberichte im Ordner `logs\reports` abgelegt.

Kostenlose Nutzung auf eigenes Risiko!


